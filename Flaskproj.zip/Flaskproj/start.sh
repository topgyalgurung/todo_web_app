pip install -r requirements.txt
python3 sql.py
python3 app.py